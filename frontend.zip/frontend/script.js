// Global variables
let map;
let deviceMarkers = new Map();
let devices = [];

// Initialize the map
function initMap() {
    // Create map centered on a default location (you can change this)
    map = L.map('map').setView([20.5937, 78.9629], 5); // Centered on India
    
    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
}

// Create a custom icon for GPS devices
function createDeviceIcon() {
    return L.divIcon({
        className: 'device-marker',
        html: `<div style="
            background: #4CAF50;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            border: 3px solid white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        "></div>`,
        iconSize: [20, 20],
        iconAnchor: [10, 10]
    });
}

// Fetch devices from the API
async function fetchDevices() {
    try {
        const response = await fetch('http://34.131.120.221:3001/coordinates');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        devices = data;
        updateMap();
        updateDeviceList();
        updateDeviceCount();
    } catch (error) {
        console.error('Failed to fetch devices:', error);
        showError('Failed to load device data. Please check if the server is running.');
    }
}

// Update map with device markers
function updateMap() {
    // Clear existing markers
    deviceMarkers.forEach(marker => {
        map.removeLayer(marker);
    });
    deviceMarkers.clear();
    
    // Add new markers
    devices.forEach(device => {
        if (device.latitude && device.longitude) {
            const marker = L.marker([device.latitude, device.longitude], {
                icon: createDeviceIcon()
            }).addTo(map);
            
            // Create popup content
            const popupContent = `
                <div style="font-family: Arial, sans-serif;">
                    <h4 style="margin: 0 0 10px 0; color: #333;">Device: ${device.imei}</h4>
                    <p style="margin: 5px 0;"><strong>Coordinates:</strong><br>
                    ${device.latitude.toFixed(6)}, ${device.longitude.toFixed(6)}</p>
                    ${device.speed !== undefined ? `<p style="margin: 5px 0;"><strong>Speed:</strong> ${device.speed} km/h</p>` : ''}
                    ${device.timestamp ? `<p style="margin: 5px 0;"><strong>Last Update:</strong><br>${new Date(device.timestamp).toLocaleString()}</p>` : ''}
                </div>
            `;
            
            marker.bindPopup(popupContent);
            deviceMarkers.set(device.imei, marker);
        }
    });
    
    // Auto-fit map to show all markers
    if (devices.length > 0) {
        const validDevices = devices.filter(d => d.latitude && d.longitude);
        if (validDevices.length > 0) {
            const group = new L.featureGroup(Array.from(deviceMarkers.values()));
            map.fitBounds(group.getBounds().pad(0.1));
        }
    }
}

// Update device list in sidebar
function updateDeviceList() {
    const deviceListElement = document.getElementById('deviceList');
    
    if (devices.length === 0) {
        deviceListElement.innerHTML = '<div class="no-devices">No devices found</div>';
        return;
    }
    
    const deviceItems = devices.map(device => `
        <div class="device-item" onclick="focusDevice('${device.imei}')">
            <div class="device-imei">IMEI: ${device.imei}</div>
            ${device.latitude && device.longitude ? `
                <div class="device-coords">
                    📍 ${device.latitude.toFixed(6)}, ${device.longitude.toFixed(6)}
                    ${device.speed !== undefined ? ` | 🚗 ${device.speed} km/h` : ''}
                </div>
            ` : '<div class="device-coords">📍 No location data</div>'}
            ${device.timestamp ? `
                <div class="device-timestamp">
                    🕒 ${new Date(device.timestamp).toLocaleString()}
                </div>
            ` : ''}
        </div>
    `).join('');
    
    deviceListElement.innerHTML = deviceItems;
}

// Focus on a specific device on the map
function focusDevice(imei) {
    const marker = deviceMarkers.get(imei);
    if (marker) {
        map.setView(marker.getLatLng(), 15);
        marker.openPopup();
    }
}

// Update device count
function updateDeviceCount() {
    const countElement = document.getElementById('deviceCount');
    countElement.textContent = devices.length;
}

// Show error message
function showError(message) {
    const deviceListElement = document.getElementById('deviceList');
    deviceListElement.innerHTML = `<div class="no-devices" style="color: #ff6b6b;">⚠️ ${message}</div>`;
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    initMap();
    fetchDevices();
    
    // Refresh button
    document.getElementById('refreshBtn').addEventListener('click', function() {
        fetchDevices();
    });
    
    // Auto-refresh every 30 seconds
    setInterval(fetchDevices, 30000);
});

// Handle marker clicks to show device info
function onMarkerClick(device) {
    // This function can be extended to show more detailed info
    console.log('Clicked device:', device);
}